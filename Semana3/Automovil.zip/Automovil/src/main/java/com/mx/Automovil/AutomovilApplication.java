package com.mx.Automovil;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AutomovilApplication {

	public static void main(String[] args) {
		SpringApplication.run(AutomovilApplication.class, args);
	}

}

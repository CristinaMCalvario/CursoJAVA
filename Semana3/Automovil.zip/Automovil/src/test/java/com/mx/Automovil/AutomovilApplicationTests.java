package com.mx.Automovil;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutomovilApplicationTests {

	@Test
	void contextLoads() {
	}

}
